package com.example.demo.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

@Entity
@Table(name = "BIT240101_DishCategories")
public class DishCategory_BIT240101 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BIT240101_Id")
    private Long id;

    @NotBlank(message = "Category name cannot be blank")
    @Column(name = "BIT240101_Name", nullable = false)
    private String name;

    @Column(name = "BIT240101_Description")
    private String description;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    private List<Dish_BIT240101> dishes;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<Dish_BIT240101> getDishes() { return dishes; }
    public void setDishes(List<Dish_BIT240101> dishes) { this.dishes = dishes; }
}