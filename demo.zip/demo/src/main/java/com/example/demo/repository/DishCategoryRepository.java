package com.example.demo.repository;

import com.example.demo.model.DishCategory_BIT240101;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DishCategoryRepository extends JpaRepository<DishCategory_BIT240101, Long> {
}