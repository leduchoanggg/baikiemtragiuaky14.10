package com.example.demo.repository;

import com.example.demo.model.DishImage_BIT240101;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DishImageRepository extends JpaRepository<DishImage_BIT240101, Long> {
    List<DishImage_BIT240101> findByDishId(Long dishId);
}