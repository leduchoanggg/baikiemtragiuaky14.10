package com.example.demo.controller;

import com.example.demo.model.Dish_BIT240101;
import com.example.demo.model.DishCategory_BIT240101;
import com.example.demo.model.DishImage_BIT240101;
import com.example.demo.repository.DishRepository;
import com.example.demo.repository.DishCategoryRepository;
import com.example.demo.repository.DishImageRepository;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/dishes")
public class DishController {

    @Autowired
    private DishRepository dishRepository;

    @Autowired
    private DishCategoryRepository categoryRepository;

    @Autowired
    private DishImageRepository imageRepository;

    // Chức năng 2 & 7: Danh sách, lọc động, sắp xếp và đa ngôn ngữ
    @GetMapping
    public String listDishes(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Boolean isAvailable,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false, defaultValue = "id") String sortBy,
            @RequestParam(required = false, defaultValue = "asc") String direction,
            @RequestParam(required = false, defaultValue = "en") String lang,
            Model model) {

        // Xây dựng Specification lọc động tại database
        Specification<Dish_BIT240101> spec = (root, query, cb) -> cb.conjunction();

        if (keyword != null && !keyword.trim().isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("name")), "%" + keyword.toLowerCase() + "%"));
        }
        if (categoryId != null) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("dishCategoryId"), categoryId));
        }
        if (isAvailable != null) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("isAvailable"), isAvailable));
        }
        if (minPrice != null) {
            spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), minPrice));
        }
        if (maxPrice != null) {
            spec = spec.and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), maxPrice));
        }

        // Sắp xếp
        Sort sort = direction.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        List<Dish_BIT240101> dishes = dishRepository.findAll(spec, sort);

        model.addAttribute("dishes", dishes);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("lang", lang);
        
        // Giữ lại giá trị tìm kiếm trên form
        model.addAttribute("keyword", keyword);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("isAvailable", isAvailable);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("maxPrice", maxPrice);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("direction", direction);

        return "dish/list";
    }

    // Trang thêm mới món ăn
    @GetMapping("/create")
    public String createForm(Model model, @RequestParam(required = false, defaultValue = "en") String lang) {
        model.addAttribute("dish", new Dish_BIT240101());
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("lang", lang);
        return "dish/create";
    }

    // Xử lý lưu món ăn mới kèm Validation
    @PostMapping("/create")
    public String saveDish(@Valid @ModelAttribute("dish") Dish_BIT240101 dish,
                           BindingResult result,
                           Model model,
                           @RequestParam(required = false, defaultValue = "en") String lang) {
        
        // Kiểm tra trùng tên món trong cùng một loại (Validation bắt buộc)
        if (dish.getDishCategoryId() != null && dish.getName() != null) {
            boolean exists = dishRepository.existsByNameAndDishCategoryId(dish.getName(), dish.getDishCategoryId());
            if (exists) {
                result.rejectValue("name", "error.dish", "Tên món ăn đã tồn tại trong loại này!");
            }
        }

        if (result.hasErrors()) {
            model.addAttribute("categories", categoryRepository.findAll());
            model.addAttribute("lang", lang);
            return "dish/create";
        }

        dishRepository.save(dish);
        return "redirect:/dishes?lang=" + lang;
    }

    // Trang chi tiết món ăn (Hiển thị nhiều ảnh, ảnh đại diện)
    @GetMapping("/detail/{id}")
    public String detailDish(@PathVariable Long id, Model model, @RequestParam(required = false, defaultValue = "en") String lang) {
        Dish_BIT240101 dish = dishRepository.findById(id).orElse(null);
        if (dish == null) {
            return "redirect:/dishes?lang=" + lang;
        }
        model.addAttribute("dish", dish);
        model.addAttribute("images", imageRepository.findByDishId(id));
        model.addAttribute("lang", lang);
        return "dish/detail";
    }

    // Chức năng 5: Xóa loại món ăn có ràng buộc nghiệp vụ (Không cho xóa nếu có món sử dụng)
    @GetMapping("/categories/delete/{id}")
    public String deleteCategory(@PathVariable Long id, RedirectAttributes redirectAttributes, @RequestParam(required = false, defaultValue = "en") String lang) {
        DishCategory_BIT240101 category = categoryRepository.findById(id).orElse(null);
        if (category != null) {
            if (category.getDishes() != null && !category.getDishes().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Không thể xóa loại món ăn này vì đang có món sử dụng!");
            } else {
                categoryRepository.delete(category);
            }
        }
        return "redirect:/dishes?lang=" + lang;
    }
}