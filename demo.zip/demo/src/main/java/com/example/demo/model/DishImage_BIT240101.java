package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "BIT240101_DishImages")
public class DishImage_BIT240101 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BIT240101_Id")
    private Long id;

    @Column(name = "BIT240101_ImageUrl", nullable = false)
    private String imageUrl;

    @Column(name = "BIT240101_IsThumbnail")
    private Boolean isThumbnail = false;

    @Column(name = "BIT240101_DishId")
    private Long dishId;

    @ManyToOne
    @JoinColumn(name = "BIT240101_DishId", insertable = false, updatable = false)
    private Dish_BIT240101 dish;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public Boolean getIsThumbnail() { return isThumbnail; }
    public void setIsThumbnail(Boolean isThumbnail) { this.isThumbnail = isThumbnail; }
    public Long getDishId() { return dishId; }
    public void setDishId(Long dishId) { this.dishId = dishId; }
    public Dish_BIT240101 getDish() { return dish; }
    public void setDish(Dish_BIT240101 dish) { this.dish = dish; }
}