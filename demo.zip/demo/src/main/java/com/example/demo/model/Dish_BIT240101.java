package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Entity
@Table(name = "BIT240101_Dishes")
public class Dish_BIT240101 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BIT240101_Id")
    private Long id;

    @NotBlank(message = "Dish name cannot be blank")
    @Column(name = "BIT240101Name", nullable = false)
    private String name;

    @NotNull(message = "Price is required")
    @Min(value = 1, message = "Price must be greater than 0")
    @Column(name = "BIT240101_Price", nullable = false)
    private Double price;

    @NotNull(message = "Preparation time is required")
    @Min(value = 1, message = "Preparation time must be greater than 0")
    @Column(name = "BIT240101_PreparationTime", nullable = false)
    private Integer preparationTime;

    @Column(name = "BIT240101_IsAvailable")
    private Boolean isAvailable = true;

    @Column(name = "BIT240101_Description")
    private String description;

    @Column(name = "BIT240101_DishCategoryId")
    private Long dishCategoryId;

    @ManyToOne
    @JoinColumn(name = "BIT240101_DishCategoryId", insertable = false, updatable = false)
    private DishCategory_BIT240101 category;

    @OneToMany(mappedBy = "dish", cascade = CascadeType.ALL)
    private List<DishImage_BIT240101> images;

    // Yêu cầu Chức năng 3: Phân loại thời gian chế biến không lưu vào DB
    @Transient
    public String getPreparationCategory() {
        if (preparationTime != null && preparationTime <= 15) {
            return "Quick / Nhanh";
        }
        return "Regular / Thông thường";
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public Integer getPreparationTime() { return preparationTime; }
    public void setPreparationTime(Integer preparationTime) { this.preparationTime = preparationTime; }
    public Boolean getIsAvailable() { return isAvailable; }
    public void setIsAvailable(Boolean isAvailable) { this.isAvailable = isAvailable; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Long getDishCategoryId() { return dishCategoryId; }
    public void setDishCategoryId(Long dishCategoryId) { this.dishCategoryId = dishCategoryId; }
    public DishCategory_BIT240101 getCategory() { return category; }
    public void setCategory(DishCategory_BIT240101 category) { this.category = category; }
    public List<DishImage_BIT240101> getImages() { return images; }
    public void setImages(List<DishImage_BIT240101> images) { this.images = images; }
}