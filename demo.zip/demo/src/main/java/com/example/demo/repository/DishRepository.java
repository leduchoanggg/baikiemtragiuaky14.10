package com.example.demo.repository;

import com.example.demo.model.Dish_BIT240101;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DishRepository extends JpaRepository<Dish_BIT240101, Long>, JpaSpecificationExecutor<Dish_BIT240101> {
    // Kiểm tra tên món không được trùng trong cùng một loại (theo yêu cầu validation)
    boolean existsByNameAndDishCategoryId(String name, Long dishCategoryId);
}